package org.example.proyecto.auth.dto;

import lombok.Data;

@Data
public class JwtAuthResponse {
    String token;
}
