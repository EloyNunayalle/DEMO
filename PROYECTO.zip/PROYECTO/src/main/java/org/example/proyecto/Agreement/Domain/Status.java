package org.example.proyecto.Agreement.Domain;

public enum Status {
    PENDING, ACCEPTED, REJECTED
}
