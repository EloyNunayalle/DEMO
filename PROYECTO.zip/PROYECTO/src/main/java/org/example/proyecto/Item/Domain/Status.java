package org.example.proyecto.Item.Domain;

public enum Status {
    PENDING, APPROVED, REJECTED
}
