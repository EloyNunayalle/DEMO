package org.example.proyecto.Item.Domain;

public enum Condition {
    NEW, USED
}
