package org.example.proyecto.Usuario.Domain;

public enum Role {
    ADMIN, USER
}
